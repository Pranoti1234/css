<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $con = mysqli_connect("localhost", "root", "", "community", 3306);

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get the POST data from the form
    $jobTitle = $_POST['jobTitle'] ?? null;
    $name = $_POST['applicantName'] ?? null;
    $age = $_POST['applicantAge'] ?? null;
    $previousWork = $_POST['previousWork'] ?? null;
    $experience = $_POST['workExperience'] ?? 0;
    $address = $_POST['address'] ?? null;
    $language = $_POST['language'] ?? null;
    $jobType = $_POST['jobType'] ?? null;
    $email = $_POST['email'] ?? null;

    // Prepare the query (make sure your table includes a jobTitle column)
    $stmt = $con->prepare("INSERT INTO job (jobTitle, applicantName, applicantAge, previousWork, workExperience, address, language, jobType, email) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("ssissssss", $jobTitle, $name, $age, $previousWork, $experience, $address, $language, $jobType, $email);

    if ($stmt->execute()) {
        echo "<p style='color: green;'>Application submitted successfully.</p><br><br>";
    } else {
        echo "<p style='color: red;'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
    $con->close();

    // Optional redirect (you can comment this during testing)
    header("Location: http://localhost/community/job-listings.html");
    exit();
}
?>
