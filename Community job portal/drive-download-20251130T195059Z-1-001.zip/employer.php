<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $con = mysqli_connect("localhost", "root", "", "community", 3306);

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get the POST data
    $name = $_POST['businessmanName'] ?? null;
    $businessName = $_POST['businessName'] ?? null;
    $requiredSkills = $_POST['requiredSkills'] ?? null;
    $experience = $_POST['experience'] ?? 0;
    $preferredJob = $_POST['jobType'] ?? null;

    // Prepare and execute insert query
    $stmt = "INSERT INTO employer (businessmanName, businessName, requiredSkills,jobType,experience) VALUES ('$name', '$businessName', '$requiredSkills', '$preferredJob', '$experience')";
    
    if ($con->query($stmt) === TRUE) {
        echo "<p style='color: green;'>Employer record inserted successfully.</p><br><br>";
    } else {
        echo "<p style='color: red;'>Error</p>";
    }


    mysqli_close($con);

    header("Location: http://localhost/community/employer-dashboard.html");
}
?>
