<?php
$con = mysqli_connect("localhost", "root", "", "community", 3306);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT jobTitle, applicantName FROM job ORDER BY id DESC";
$result = mysqli_query($con, $query);

$applicants = [];

while ($row = mysqli_fetch_assoc($result)) {
    $applicants[] = $row;
}

header('Content-Type: application/json');
echo json_encode($applicants);

mysqli_close($con);
?>
