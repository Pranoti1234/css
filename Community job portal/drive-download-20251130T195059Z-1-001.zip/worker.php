<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $con = mysqli_connect("localhost", "root", "", "community", 3306);

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $name = $_POST['name'] ?? null;
    $dob = $_POST['dob'] ?? null;
    $prevJob = $_POST['prevJob'] ?? null;
    $experience = $_POST['experience'] ?? 0;
    $education = $_POST['education'] ?? null;
    $preferredJob = $_POST['preferredJob'] ?? null;
    $email = $_POST['email'] ?? null;
    $location = $_POST['location'] ?? null;

    $stmt = "INSERT INTO worker(name, dob, prevJob, experience, education, preferredJob, email, location) 
             VALUES ('$name', '$dob', '$prevJob', '$experience', '$education', '$preferredJob', '$email', '$location')";

    if ($con->query($stmt) === TRUE) {
        mysqli_close($con);
        header("Location: http://localhost/community/homepage.html");
        exit(); // important to prevent further execution
    } else {
        echo "<p style='color: red;'>Error: " . $con->error . "</p>";
    }

    mysqli_close($con);
}
?>

